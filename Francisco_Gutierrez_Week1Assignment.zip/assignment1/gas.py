gallons = input("How many gallons of gasoline?: ")
liters = gallons * 3.7854
barrels = gallons/19.5
price = gallons * 3.65
print("You have used " + str(gallons) + " gallons, which is equivalent to " + str(liters) + " liters and " + str(barrels) + " barrels. This costs approximately $ " + str(price))
