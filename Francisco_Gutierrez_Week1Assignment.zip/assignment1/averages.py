num1 = input("Enter first number: ")
num2 = input("Enter second number: ")
arith_mean =(num1+num2)/2
geom_mean = (num1*num2)**(0.5)
root_mean = ((num1**2 + num2**2)/2)**(0.5)
print("Your two numbers yield a mean of " + str(arith_mean) + ", a geometric mean of " +
      str(geom_mean) + " and a root mean square of " + str(root_mean))
