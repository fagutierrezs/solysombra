

def myPig(some_name): 
	one = some_name[1].upper()
	two = some_name[2:]
	three = some_name[0].lower()
	four = "ay"
	return(one+two+three+four)

names1 = input("Enter your name: ").split()
 

penultimate=map(myPig, names1)

" ".join(penultimate)
